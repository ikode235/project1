package water_fin;

public class reservation {
    String online; //온라인
    String offline; //오프라인

    public reservation(String online, String offline) {
        this.online = online;
        this.offline = offline;
    }
}