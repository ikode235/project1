package Water;

public class reservation {
    String online; //온라인 예약
    String offline; //오프라인 예약

    public reservation(String online, String offline) {
        this.online = online;
        this.offline = offline;
    }
}