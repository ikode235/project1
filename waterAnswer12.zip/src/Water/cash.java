package Water;

import java.util.Scanner;

public class cash {


    // 메인 한개. 메인 이동 없음.
    public static void main(String[] args) {
        int m = 120000;                                         // ->>>>>>>>>>>>>>>>>>>>>>>>>>>> 값 임의로 넣음. 수정하기.
        System.out.println("현재 금액은" + m +"입니다");
        Scanner scanner = new Scanner(System.in);


        // 계산 넣기. 수정.

        System.out.println("현금 영수증을 하시겠습니까?");
        System.out.println("[1] 하겠습니다. [2] 하지않겠습니다");
        int receipt = scanner.nextInt();

        System.out.println();


        for(;;) {
            if(receipt == 1) {
                System.out.println("번호를 입력해주세요");
                Scanner scanner1 = new Scanner(System.in);
                int num1 = scanner1.nextInt();
                System.out.println("입력하신 번호가 맞습니까? [1] 맞습니다 , [2] 아닙니다");
                int num2 = scanner1.nextInt();
                if(num2 == 1) {
                    System.out.println("현금 영수증을 발급하겠습니다");
                    System.out.println("\n========================================="
                            + "===============================\n");
                    System.out.println("* 포인트를 적립하시겠습니까? *");
                    System.out.println("[1] 포인트 적립 하기\n[2] 포인트 적립 안함");

                    int point = scanner1.nextInt();
                    
                    if(point == 1) {
                        System.out.println("휴대폰 번호를 입력해주세요.  ex)01012341234");
                        String phone_number = scanner1.next();
                        System.out.println("적립되었습니다.");
                        System.out.println("안녕히 가세용 ~.~");
                        System.out.println("========================================="
                                + "===============================\n");
                    }else{
                        System.out.println("안녕히 가세용 ~.~");
                    }
                    System.out.println("\n========================================="
                            + "===============================\n");
                    break;
                }
                System.out.println("번호를 다시 입력해주세요.");
            }
            System.out.println("완료되었습니다.");
            System.out.println("\n========================================="
                    + "===============================\n");
            System.out.println("* 포인트를 적립하시겠습니까? *");
            System.out.println("[1] 포인트 적립 하기\n[2] 포인트 적립 안함");

            int point = scanner.nextInt();
            if(point == 1) {
                System.out.println("휴대폰 번호를 입력해주세요.  ex)01012341234");
                String phone_number = scanner.next();
                System.out.println("적립되었습니다.");
                System.out.println("안녕히 가세용 ~.~");
                System.out.println("========================================="
                        + "===============================\n");
            }else{
                System.out.println("안녕히 가세용 ~.~");
            }
            break;
        }
    }
}